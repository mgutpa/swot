package com.sterlite.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * @author dharmaraj.pawale@sterlite.com
 * @creation_date 12th-Sep-2020
 * @version 1.0
 * @copyright Sterlite Technologies Ltd.
 */
@SpringBootTest
class ProductMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
