insert into product values(1001,'LED TV','Sony',88000.00);
insert into product values(1002,'Refrigerator','Whirlpool',42000.00);
insert into product values(1003,'LED TV','LG',75000.00);
insert into product values(1004,'Laptop','HP',34500.00);
insert into product values(1005,'Washing Machine','Whirlpool',25000.00);